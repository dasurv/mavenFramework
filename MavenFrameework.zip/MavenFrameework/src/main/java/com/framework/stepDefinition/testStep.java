package com.framework.stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

public class testStep {
	
	WebDriver driver;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vaishnavi\\eclipse-workspace\\MavenFrameework\\drivers\\chromedriver.exe");
		this.driver=new ChromeDriver();
		this.driver.manage().window().maximize();
		this.driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		this.driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
	}
	
	@After
	public void tearDown() {
		this.driver.manage().deleteAllCookies();
		this.driver.close();
		this.driver.quit();
	}
	
	@Given("^I want to write a step with precondition$")
	public void iWantToWriteAStepWithPrecondition() throws Throwable {
		System.out.println("Hello");
		driver.get("https://stackoverflow.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[text()='Log in']")).click();
	}
}
